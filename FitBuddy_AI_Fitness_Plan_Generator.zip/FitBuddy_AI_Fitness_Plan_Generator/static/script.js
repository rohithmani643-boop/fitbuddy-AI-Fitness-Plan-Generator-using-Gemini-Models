const form = document.getElementById("planForm");
const result = document.getElementById("result");
const statusEl = document.getElementById("status");
const btn = document.getElementById("generateBtn");

function esc(s){return String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

function renderPlan(plan){
  document.getElementById("planTitle").textContent = plan.summary || "Your Fitness Plan";
  let html = `<div class="summary"><b>${esc(plan.summary || "")}</b>${plan.bmi ? `<div class="bmi">BMI reference: ${esc(plan.bmi)} (not a diagnosis)</div>` : ""}</div>`;
  html += `<div class="week">`;
  (plan.weekly_plan || []).forEach(d=>{
    html += `<article class="day"><strong>${esc(d.day)}</strong><h3>${esc(d.focus)}</h3><ul>${(d.exercises||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul></article>`;
  });
  html += `</div>`;
  html += `<div class="section"><h3>Nutrition</h3><ul>${(plan.nutrition||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`;
  html += `<div class="section"><h3>Safety</h3><ul>${(plan.safety||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`;
  result.innerHTML = html;
}

form.addEventListener("submit", async e=>{
  e.preventDefault();
  btn.disabled = true; btn.textContent = "Generating...";
  statusEl.textContent = "Creating your personalized plan...";
  const data = Object.fromEntries(new FormData(form).entries());
  try{
    const r = await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    const out = await r.json();
    if(!out.success) throw new Error("Generation failed");
    renderPlan(out.plan);
    statusEl.textContent = out.mode === "ai" ? "AI-generated plan created." : "Plan created using FitBuddy's local planner.";
    loadHistory();
  }catch(err){statusEl.textContent = "Something went wrong. Check the terminal for details."}
  finally{btn.disabled=false;btn.textContent="Generate My Plan";}
});

async function loadHistory(){
  const box=document.getElementById("history");
  try{
    const r=await fetch("/api/history"); const rows=await r.json();
    box.innerHTML = rows.length ? rows.map(x=>`<div class="history-item"><b>${esc(x.profile.name||"User")}</b> — ${esc(x.profile.goal)} — ${esc(x.created_at)}</div>`).join("") : "No saved plans yet.";
  }catch(e){box.textContent="Could not load history."}
}
document.getElementById("historyBtn").addEventListener("click",loadHistory);
loadHistory();
