# FitBuddy — AI Fitness Plan Generator

A student-friendly full-stack fitness planner built with Python Flask, HTML/CSS/JavaScript and an optional OpenAI-compatible LLM.

## Features
- Personalized workout plan
- Muscle gain / weight loss / general fitness goals
- Equipment and training-day selection
- Nutrition and safety guidance
- BMI reference calculation
- SQLite plan history
- Optional AI/LLM generation
- Local fallback planner works without an API key
- Print-friendly plan

## Project structure

```text
FitBuddy_AI_Fitness_Plan_Generator/
├── app.py
├── requirements.txt
├── .env.example
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```

## Run in VS Code

1. Open this folder in VS Code.
2. Open Terminal.
3. Create a virtual environment:

Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

4. Install dependencies:
```bash
pip install -r requirements.txt
```

5. Optional AI setup:
- Copy `.env.example` to `.env`
- Put your API key in `OPENAI_API_KEY`
- If you do not add a key, FitBuddy still works with its built-in local planner.

6. Start:
```bash
python app.py
```

7. Open:
```text
http://127.0.0.1:5000
```

## API endpoints

`POST /api/generate` — generate and save a plan.

`GET /api/history` — return the latest saved plans.

## Important
This is an educational fitness-planning application, not a medical diagnosis tool. Users should stop exercise if they experience sharp pain, dizziness or unusual symptoms and seek appropriate professional advice.
