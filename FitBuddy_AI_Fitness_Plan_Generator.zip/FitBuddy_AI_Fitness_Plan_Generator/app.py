import os, json, sqlite3
from datetime import datetime
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
DB = "fitbuddy.db"

def init_db():
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        profile TEXT NOT NULL,
        plan TEXT NOT NULL
    )""")
    con.commit()
    con.close()

def rule_based_plan(data):
    goal = data.get("goal", "Muscle Gain")
    level = data.get("level", "Beginner")
    equipment = data.get("equipment", "Dumbbells")
    days = int(data.get("days", 4))

    if goal == "Weight Loss":
        split = [
            ("Day 1", "Full Body + 15 min brisk cardio"),
            ("Day 2", "Upper Body + 15 min cardio"),
            ("Day 3", "Lower Body + core"),
            ("Day 4", "Full Body + 20 min cardio"),
            ("Day 5", "Active recovery / walking"),
            ("Day 6", "Core + light cardio"),
            ("Day 7", "Rest")
        ]
    elif goal == "Muscle Gain":
        split = [
            ("Day 1", "Chest + Triceps"),
            ("Day 2", "Back + Biceps"),
            ("Day 3", "Legs"),
            ("Day 4", "Shoulders + Abs"),
            ("Day 5", "Full Body / weak points"),
            ("Day 6", "Light cardio + mobility"),
            ("Day 7", "Rest")
        ]
    else:
        split = [
            ("Day 1", "Full Body Strength"),
            ("Day 2", "Cardio + Core"),
            ("Day 3", "Upper Body"),
            ("Day 4", "Lower Body"),
            ("Day 5", "Full Body"),
            ("Day 6", "Mobility + light cardio"),
            ("Day 7", "Rest")
        ]

    split = split[:days] + [("Rest", "Recovery, stretching and sleep")] if days < 7 else split

    exercises = {
        "Chest + Triceps": ["Push-ups 3×10-15", "Dumbbell Floor Press 4×8-12", "Dumbbell Fly 3×10-12", "Overhead Triceps Extension 3×10-12"],
        "Back + Biceps": ["One-arm Dumbbell Row 4×8-12", "Dumbbell Romanian Deadlift 3×8-12", "Dumbbell Curl 3×10-12", "Hammer Curl 3×10-12"],
        "Legs": ["Goblet Squat 4×8-12", "Reverse Lunge 3×10/leg", "Romanian Deadlift 3×8-12", "Calf Raise 4×15-20"],
        "Shoulders + Abs": ["Dumbbell Shoulder Press 4×8-12", "Lateral Raise 3×12-15", "Rear Delt Fly 3×12-15", "Plank 3×30-60 sec", "Reverse Crunch 3×12-15"],
        "Full Body": ["Goblet Squat 3×10", "Push-ups 3×10-15", "Dumbbell Row 3×10", "Shoulder Press 3×10", "Plank 3×45 sec"]
    }

    weekly = []
    for day, focus in split:
        key = focus.split(" + ")[0]
        ex = exercises.get(focus, exercises.get(key, exercises["Full Body"]))
        weekly.append({"day": day, "focus": focus, "exercises": ex})

    height = float(data.get("height") or 0)
    weight = float(data.get("weight") or 0)
    bmi = round(weight / ((height/100)**2), 1) if height > 0 and weight > 0 else None

    return {
        "summary": f"{goal} plan for a {level.lower()} using {equipment.lower()}.",
        "bmi": bmi,
        "weekly_plan": weekly,
        "nutrition": [
            "Aim for a protein source in every main meal.",
            "Include vegetables and 2–3 servings of fruit across the day.",
            "Drink water regularly; increase intake around workouts.",
            "For muscle gain, use a small calorie surplus; for fat loss, use a modest calorie deficit.",
            "Sleep about 7–9 hours and keep at least one recovery day."
        ],
        "safety": [
            "Warm up for 5–10 minutes before training.",
            "Use controlled form and stop if you feel sharp pain, dizziness or unusual symptoms.",
            "Increase weight or repetitions gradually rather than forcing heavy loads."
        ]
    }

def ai_plan(data):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return rule_based_plan(data), "local"

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        prompt = f"""Create a practical fitness plan as JSON for this user:
{json.dumps(data)}
Return keys: summary, weekly_plan (array of day/focus/exercises), nutrition (array), safety (array), bmi.
Do not diagnose medical conditions. Keep exercise advice general and safe."""
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": "You are a fitness planning assistant. Give safe, general fitness information."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.5
        )
        return json.loads(response.choices[0].message.content), "ai"
    except Exception:
        return rule_based_plan(data), "local-fallback"

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/api/generate")
def generate():
    data = request.get_json(force=True)
    plan, mode = ai_plan(data)
    con = sqlite3.connect(DB)
    con.execute("INSERT INTO plans(created_at, profile, plan) VALUES (?, ?, ?)",
                (datetime.now().isoformat(timespec="seconds"), json.dumps(data), json.dumps(plan)))
    con.commit()
    con.close()
    return jsonify({"success": True, "mode": mode, "plan": plan})

@app.get("/api/history")
def history():
    con = sqlite3.connect(DB)
    rows = con.execute("SELECT id, created_at, profile, plan FROM plans ORDER BY id DESC LIMIT 10").fetchall()
    con.close()
    return jsonify([{"id": r[0], "created_at": r[1], "profile": json.loads(r[2]), "plan": json.loads(r[3])} for r in rows])

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
